#include <iostream>
#include <string>
using namespace std;
void strpack(string y)
{
    string x; 
    int i=0, j=0, k;
    k=y.size();
    x=y.at(i);
    for(i=1, j=0; i<k ;i++)
    {
        
        if(y.at(i) != x.at(j))
        {
            x= x + y.at(i); 
            j++;
        }
    }
    cout<<x;
}
int main()
{
    string cad;
    cout<<"Insira uma cadeia de caracteres:\n";
	getline (cin,cad);
    strpack(cad);

    return 0;
}