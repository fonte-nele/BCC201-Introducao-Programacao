#include <iostream>
#include <string>
using namespace std;
void strpack(string y)
{
    string x;
    char z;
    int i, k;
    k=y.size();
    for(i=0; i<k ;i++)
    {
         if(y.at(i) != ' ' && y.at(i) != 'z')
        {
            z= y.at(i)+1;
            x= x + z; 
        }
        else
            if (y.at(i) == 'z')
            {
                z= 'a';
                x= x + z;
            }
            else
            {
                z= y.at(i);
                x= x + z;
            }
    }
    cout<<x;
}
int main()
{
    string cad;
    cout<<"Insira uma cadeia de caracteres:\n";
	getline (cin,cad);
    strpack(cad);

    return 0;
}